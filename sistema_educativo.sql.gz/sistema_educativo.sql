-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 24-11-2008 a las 08:45:43
-- Versión del servidor: 5.0.67
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sistema_educativo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura_ua`
--

CREATE TABLE IF NOT EXISTS `asignatura_ua` (
  `curp` varchar(20) NOT NULL,
  `codigo` int(6) NOT NULL,
  `total_creditos` smallint(6) default NULL,
  KEY `curp` (`curp`),
  KEY `codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `asignatura_ua`
--

INSERT INTO `asignatura_ua` (`curp`, `codigo`, `total_creditos`) VALUES
('213456', 101, NULL),
('2354235', 105, 0),
('2354235', 105, 0),
('2354235', 105, 0),
('2354235', 105, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE IF NOT EXISTS `profesor` (
  `curp` varchar(20) NOT NULL,
  `nombre` varchar(12) default NULL,
  `apellido_p` varchar(15) default NULL,
  `apellido_m` varchar(15) default NULL,
  `edad` smallint(6) default NULL,
  `sexo` varchar(10) default NULL,
  `estado_civil` varchar(20) default NULL,
  `profesion` varchar(20) default NULL,
  `cedula` varchar(20) default NULL,
  `mail` varchar(30) default NULL,
  `movil` varchar(20) default NULL,
  `fecha_nacimiento` date default NULL,
  PRIMARY KEY  (`curp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`curp`, `nombre`, `apellido_p`, `apellido_m`, `edad`, `sexo`, `estado_civil`, `profesion`, `cedula`, `mail`, `movil`, `fecha_nacimiento`) VALUES
('213456', 'dfgvbh', 'jnghjv', 'bjnkvghbj', 96, 'm', 'casado', 'Derecho', 'knkbhjl', 'kkghv bj@gmail.com', 'nkgjvh ', '1912-05-04'),
('21345624', 'ddfsdf', 'sdfdsf', 'asdasd', 98, 'm', 'casado', 'Derecho', 'asdasd', 'adadasd@hotmail.com', 'asdadad', '1910-03-05'),
('2354235', 'adadasd', 'asdasd', 'asdasd', 97, 'femenino', 'soltero', 'Admon. Empresas', 'asdad', 'asdasda@gmail.com', '245423567', '1911-03-04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidad_aprendizaje`
--

CREATE TABLE IF NOT EXISTS `unidad_aprendizaje` (
  `codigo` int(6) NOT NULL,
  `unidad_aprendizaje` varchar(30) default NULL,
  `creditos` smallint(3) default NULL,
  `plan_estudio` varchar(15) default NULL,
  `observaciones` varchar(255) default NULL,
  PRIMARY KEY  (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `unidad_aprendizaje`
--

INSERT INTO `unidad_aprendizaje` (`codigo`, `unidad_aprendizaje`, `creditos`, `plan_estudio`, `observaciones`) VALUES
(101, 'alguito', 0, '4', '5'),
(102, 'alguiÃ±o', 88, 'Flexible', 'asd'),
(103, 'Fisica', 7, 'Flexible', 'Mecanica Clasica'),
(104, 'Educacion Artistica', 5, 'Flexible', ''),
(105, 'Algebra Lineal', 9, 'Flexible', 'Algebra requerida');

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `asignatura_ua`
--
ALTER TABLE `asignatura_ua`
  ADD CONSTRAINT `asignatura_ua_ibfk_3` FOREIGN KEY (`curp`) REFERENCES `profesor` (`curp`) ON UPDATE CASCADE,
  ADD CONSTRAINT `asignatura_ua_ibfk_4` FOREIGN KEY (`codigo`) REFERENCES `unidad_aprendizaje` (`codigo`) ON DELETE NO ACTION ON UPDATE CASCADE;
